# Mate - Music Search Engine

### Overview
Mate is an AI-powered music search engine designed to provide a rich and interactive music discovery experience. It features multi-platform search, AI-driven vibe matching, and an in-app music player with unique visualizers. The project aims to offer a Google-like search experience for music, enriched with AI insights and a stunning, modern user interface.

### User Preferences
I prefer simple language and clear, concise explanations. I want iterative development, with small, testable changes. Please ask before making major architectural changes or introducing new dependencies. Do not make changes to the `shared/schema.ts` file without explicit approval.

### System Architecture
The application is built with a React + TypeScript frontend utilizing Tailwind CSS for styling, Framer Motion for animations, and Web Audio API for visualizations. The backend uses Express.js. Key UI/UX decisions include a violet and dark blue theme inspired by jeton.com, featuring glassmorphism effects, a card-based layout for search results, and responsive design with mobile gestures for sidebar navigation.

**Key Features:**
-   **Multi-Platform Search:** Aggregates results from YouTube, SoundCloud, Jamendo, RapidAPI (Deezer), Internet Archive, and Mixcloud.
-   **AI Vibe Match:** Identifies musical vibes from humming using OpenAI GPT-5 and Whisper API.
-   **Advanced Filtering:** Sorts results by relevance, newest, popularity, or public domain, with platform filtering.
-   **In-App Music Player:** Features a glassmorphic design, NCS-style 3D particle visualizer, playback controls, like/download functionality, and supports YouTube (Iframe API) and SoundCloud.
-   **Library Management:** Provides responsive sidebar access to playlists, liked songs, and saved songs with CRUD operations.
-   **Lyrics Display:** Fetches lyrics from multiple APIs with fallback mechanisms and displays them in a modern card UI.
-   **Google-like Search:** Integrates AI answers as featured snippets alongside music search results when AI mode is active.

**Design System:**
-   **Primary Colors:** Violet (270° 60% 55%) and Blue (240° 70% 50%).
-   **Background:** Deep violet-blue (230° 35% 8%).
-   **Typography:** Inter (body), Poppins (display), JetBrains Mono (mono).
-   **Effects:** Glassmorphism with backdrop-blur, gradient animations.

### External Dependencies
-   **YouTube Data API v3:** Used for music search and playback integration.
-   **OpenAI GPT-5 & Whisper API:** Powers AI vibe matching and analysis.
-   **Puter.js:** Provides free, unlimited AI access for frontend AI capabilities using models like GPT-5-nano.
-   **lyrics.ovh API:** Primary API for fetching song lyrics.
-   **some-random-api.com:** Fallback API for fetching song lyrics.
-   **PostgreSQL Database:** Used for storing user data, songs, playlists, and library information, managed by Drizzle ORM.
-   **SoundCloud API:** Integrated for search results and playback.
-   **Jamendo, RapidAPI (Deezer), Internet Archive, Mixcloud:** Additional music sources for search aggregation.
-   **DuckDuckGo API:** Used for web search functionality with "/" prefix.
-   **https://ai-wtsg.onrender.com/chat/:** External AI API used for dynamic music-related queries.
-   **https://free-unoficial-gpt4o-mini-api-g70n.onrender.com/chat/:** Free endpoint for GPT-4o Mini used in AI mode.

## Recent Changes (October 9, 2025)
- **Web Search with "/" Prefix, SoundCloud Fix, and UI Updates - COMPLETED**:
  - ✅ **Removed inbuilt music player** (was not working properly)
    - Users now click song links to play on original platforms (YouTube, SoundCloud, etc.)
    - Clean, simple UI focused on search results
  - ✅ **Removed iTunes** from search aggregation
  - ✅ **Fixed SoundCloud integration**:
    - Updated to use multiple fallback client IDs for better reliability
    - SoundCloud tracks now show correctly in search results
    - Includes artwork, artist name, duration, and platform badge
  - ✅ **Web search with "/" prefix**:
    - Start search with "/" to search for music-related articles and information from the web
    - Uses DuckDuckGo Instant Answer API to find music-related websites
    - Shows article titles (blue), URLs (green), and descriptions in Google-style cards
    - Displays "Related Information" section with web links
    - Only shows web results (no music tracks) when "/" prefix is used
  - ✅ **Added guidance text for "/" search**:
    - Placeholder text updated: "Search for songs... (Use / for web search)"
    - Info box displayed when idle: "Pro Tip: Web Search" with instructions
    - Explains how to use "/" prefix for web article searches
  - ✅ **Updated AI mode indicator**:
    - Text now says: "AI mode is active - showing curated results"
    - Only shows when AI mode is ON and not in web search mode
    - Hides during "/" web searches to avoid confusion
  - ✅ **Search results improvements**:
    - Music tracks from: Jamendo, RapidAPI (Deezer), SoundCloud, YouTube, Internet Archive, Mixcloud
    - Web articles (when search starts with "/")
    - Direct links to play songs on original platforms
    - Clean card-based Google-style layout with thumbnails